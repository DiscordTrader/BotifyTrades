@echo off
REM Quick start script for Windows

echo ==========================================
echo Discord Trading Bot - Local Launcher
echo ==========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo X Python is not installed!
    echo Please install Python 3.11+ from https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [OK] Python found
python --version
echo.

REM Check if dependencies are installed
echo Checking dependencies...
python -c "import discord" >nul 2>&1
if errorlevel 1 (
    echo Installing dependencies...
    pip install -r requirements.txt
    echo.
)

REM Run validation script
echo Running setup validation...
python test_setup.py
echo.

REM Ask user to continue
echo.
set /p continue="Continue to start bot? (Y/N): "
if /i not "%continue%"=="Y" (
    echo.
    echo Exiting. Please fix any errors above.
    pause
    exit /b 0
)

echo.
echo Starting bot...
echo Press Ctrl+C to stop
echo.

REM Run the bot
python src/selfbot_webull.py

pause
