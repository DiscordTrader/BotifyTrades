# BotifyTrades License Server - Separate Project Setup

## Step-by-Step Guide to Create Separate Replit Project

---

## STEP 1: Create New Replit Project

1. Go to [replit.com](https://replit.com)
2. Click **"Create Repl"**
3. Select **Python** template
4. Name it: `botifytrades-license-server`
5. **IMPORTANT**: Set visibility to **Private**
6. Click **Create Repl**

---

## STEP 2: Copy These Files to New Project

Copy these files from this folder to your new Replit project:

```
main.py              → main.py
requirements.txt     → requirements.txt
admin_cli.py         → admin_cli.py
```

---

## STEP 3: Set Up Secrets in New Project

In your new Replit project, go to **Secrets** tab and add:

| Secret Name | Value | Description |
|-------------|-------|-------------|
| `DATABASE_URL` | `postgresql://user:pass@host/db` | Your PostgreSQL connection |
| `LICENSE_SECRET_KEY` | (generate secure random) | Signs license keys |
| `JWT_SECRET` | (generate secure random) | Signs validation tokens |
| `ADMIN_API_KEY` | (generate secure random) | Admin endpoint access |
| `TRIAL_DAYS` | `7` | Number of days for trial licenses |

**Generate secure keys with:**
```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

---

## STEP 4: Configure Workflow

Create `.replit` file:
```ini
run = "uvicorn main:app --host 0.0.0.0 --port 5000"
```

Or for production with gunicorn:
```ini
run = "gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:5000"
```

---

## STEP 5: Test the Server

After starting, test the endpoints:

```bash
# Check server status
curl https://your-repl-url.replit.app/api/v1/license/status

# Create a test license (requires ADMIN_API_KEY)
curl -X POST https://your-repl-url.replit.app/api/v1/admin/licenses \
  -H "Content-Type: application/json" \
  -H "X-API-Key: YOUR_ADMIN_API_KEY" \
  -d '{"customer_id": "test_user", "days": 30}'
```

---

## STEP 6: VPS Deployment (Optional)

### On Your VPS (One-time Setup):

```bash
# 1. Create deployment directory
sudo mkdir -p /opt/license-server
sudo chown $USER:$USER /opt/license-server

# 2. Create bare git repo for receiving pushes
cd /opt
git init --bare license-server.git

# 3. Create post-receive hook for auto-deploy
cat > license-server.git/hooks/post-receive << 'EOF'
#!/bin/bash
echo ">>> Deploying license server..."
GIT_WORK_TREE=/opt/license-server git checkout -f
cd /opt/license-server

# Install dependencies
pip3 install -r requirements.txt --quiet

# Restart service
sudo systemctl restart license-server

echo ">>> Deploy complete!"
EOF

chmod +x license-server.git/hooks/post-receive

# 4. Create systemd service
sudo tee /etc/systemd/system/license-server.service << 'EOF'
[Unit]
Description=BotifyTrades License Server
After=network.target postgresql.service

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/opt/license-server
Environment="DATABASE_URL=postgresql://postgres:yourpassword@localhost/licenses"
Environment="LICENSE_SECRET_KEY=your_secret_key_here"
Environment="JWT_SECRET=your_jwt_secret_here"
Environment="ADMIN_API_KEY=your_admin_key_here"
Environment="TRIAL_DAYS=7"
ExecStart=/usr/bin/python3 -m uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# 5. Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable license-server
sudo systemctl start license-server
```

### Deploy from Replit to VPS:

```bash
# 1. Initialize git (if not already)
git init

# 2. Add VPS as remote
git remote add vps ssh://ubuntu@YOUR_VPS_IP/opt/license-server.git

# 3. Deploy with one command!
git add .
git commit -m "Update license server"
git push vps main
```

---

## API Endpoints Reference

### Public Endpoints (used by bot client)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/license/status` | GET | Server health check |
| `/api/v1/license/trial` | POST | Request trial license |
| `/api/v1/license/activate` | POST | Activate license on machine |
| `/api/v1/license/validate` | POST | Validate license + get token |
| `/api/v1/license/deactivate` | POST | Deactivate from machine |

### Admin Endpoints (require X-API-Key header)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/admin/licenses` | GET | List all licenses |
| `/api/v1/admin/licenses` | POST | Create new license |
| `/api/v1/admin/licenses/{key}` | GET | Get license details |
| `/api/v1/admin/licenses/{key}/revoke` | POST | Revoke license |
| `/api/v1/admin/licenses/{key}/extend` | POST | Extend expiration |
| `/api/v1/admin/licenses/{key}/clear-activation` | POST | Clear machine binding |
| `/api/v1/admin/licenses/{key}/set-device-limit` | POST | Set max devices |

---

## Architecture After Setup

```
┌─────────────────────────────────────────────────────────────────┐
│                     YOUR INFRASTRUCTURE                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────┐    ┌────────────────────────────────┐│
│  │  Replit Project 1    │    │    Replit Project 2 (NEW)     ││
│  │  (Bot Builds)        │    │    (License Server)            ││
│  │                      │    │                                ││
│  │  - src/              │    │  - main.py                    ││
│  │  - gui_app/          │    │  - admin_cli.py               ││
│  │  - User builds       │    │  - requirements.txt           ││
│  │                      │    │                                ││
│  │  NO license_server/  │    │  Runs on port 5000            ││
│  └──────────────────────┘    └─────────────┬──────────────────┘│
│                                            │                    │
│                                            ▼                    │
│  ┌────────────────────────────────────────────────────────────┐│
│  │              VPS/Replit (api.botifytrades.com)             ││
│  │                                                            ││
│  │  ┌─────────────────┐    ┌─────────────────────────────────┐││
│  │  │ License Server  │◄───│    PostgreSQL Database          │││
│  │  │ (FastAPI)       │    │    + Daily Backups              │││
│  │  │ Port 5000/8000  │    └─────────────────────────────────┘││
│  │  └────────┬────────┘                                       ││
│  │           │                                                ││
│  └───────────┼────────────────────────────────────────────────┘│
│              │                                                  │
└──────────────┼──────────────────────────────────────────────────┘
               │
               ▼
    ┌──────────────────────┐
    │   User Bot Builds    │
    │   (Customers)        │
    │                      │
    │   Validates license  │
    │   against server     │
    └──────────────────────┘
```

---

## Security Checklist

- [ ] New Replit project is set to Private
- [ ] Secrets are stored in Replit Secrets (not hardcoded)
- [ ] VPS environment variables are in systemd service file
- [ ] PostgreSQL backups are running daily
- [ ] Admin endpoints are protected by X-API-Key header
- [ ] HTTPS is enabled (Replit provides this automatically)

---

## Admin CLI Usage

```bash
# Set environment variables first
export LICENSE_SERVER_URL="https://your-server-url"
export ADMIN_API_KEY="your_admin_key"

# Create a 30-day license
python admin_cli.py create --customer "john@email.com" --days 30

# List all licenses
python admin_cli.py list

# Get license details
python admin_cli.py details --key "BTF-XXXX-XXXX-XXXX"

# Extend a license by 30 days
python admin_cli.py extend --key "BTF-XXXX-XXXX-XXXX" --days 30

# Revoke a license
python admin_cli.py revoke --key "BTF-XXXX-XXXX-XXXX"

# Clear activation (allow re-activation on new machine)
python admin_cli.py clear-activation --key "BTF-XXXX-XXXX-XXXX"

# Set device limit
python admin_cli.py set-limit --key "BTF-XXXX-XXXX-XXXX" --limit 2
```
