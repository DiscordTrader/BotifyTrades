@echo off
REM Create distribution package for Windows EXE
REM Run this after building the EXE

echo ========================================
echo Creating Distribution Package
echo ========================================
echo.

REM Check if EXE exists
if not exist "dist\DiscordTradingBot.exe" (
    echo ERROR: EXE not found!
    echo Please run build_exe.bat first to create the executable.
    echo.
    pause
    exit /b 1
)

REM Create distribution folder
set DIST_FOLDER=TradingBot-Distribution
if exist "%DIST_FOLDER%" (
    echo Removing old distribution folder...
    rmdir /s /q "%DIST_FOLDER%"
)

echo Creating distribution folder...
mkdir "%DIST_FOLDER%"

REM Copy essential files
echo Copying files...
copy "dist\DiscordTradingBot.exe" "%DIST_FOLDER%\" >nul
copy "config.ini.example" "%DIST_FOLDER%\" >nul
copy "EXE_SETUP.md" "%DIST_FOLDER%\" >nul
copy "README.md" "%DIST_FOLDER%\" >nul

echo.
echo ========================================
echo Distribution Package Created!
echo ========================================
echo.
echo Location: %DIST_FOLDER%\
echo.
echo Contents:
echo   - DiscordTradingBot.exe     (Main executable)
echo   - config.ini.example        (Configuration template)
echo   - EXE_SETUP.md             (Setup instructions)
echo   - README.md                (User documentation)
echo.
echo Next steps:
echo 1. Test the package on a clean Windows machine
echo 2. Create a ZIP file for distribution
echo 3. Share with users
echo.
echo IMPORTANT: Do NOT include your personal config.ini or credentials!
echo.
pause
