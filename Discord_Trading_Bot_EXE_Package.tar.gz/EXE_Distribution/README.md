# Discord Trading Bot for Webull

A Discord self-bot that automatically detects BTO/STC trading signals in Discord channels and executes trades on Webull brokerage.

## ⚠️ Important Disclaimers

1. **Discord Self-Bots**: Using self-bots violates Discord's Terms of Service and may result in account termination. Use at your own risk.
2. **Trading Risk**: This bot executes real trades with real money. Always test with paper trading first.
3. **No Warranty**: This software is provided as-is with no guarantees. You are responsible for all trades executed.

## Features

- ✅ Detects BTO/STC signals for both stocks and options
- ✅ Supports lowercase and uppercase option types (50C or 50c)
- ✅ Paper trading mode for safe testing
- ✅ Secure credential management via environment variables
- ✅ Multiple channel monitoring
- ✅ Author and guild filtering
- ✅ Comprehensive logging

## Signal Formats

### Options
```
BTO 2 HOOD 67C 05/23 @0.74
BTO 1 RKLB 50c 11/14 @4.50
STC 1 AAPL 190P 11/15 @3.10
```

Format: `BTO/STC QTY SYMBOL STRIKE[C/P] MM/DD @PRICE`

### Stocks
```
BTO 10 AAPL @189.50
STC 5 AMD @128.20
```

Format: `BTO/STC QTY SYMBOL @PRICE`

## Deployment Options

### Option 1: Windows EXE (Standalone Executable)
**Best for:** Non-technical users, easy distribution

1. Download the pre-built EXE package
2. Follow setup guide in `EXE_SETUP.md`
3. No Python installation required
4. See `build_instructions.md` to build your own EXE

### Option 2: Run on Replit (Cloud)
**Best for:** Testing, development, 24/7 operation

- Use Replit Secrets for credentials (most secure)
- Keep browser tab open or use Reserved VM
- Follow setup instructions below

### Option 3: Run on Local Machine (Python)
**Best for:** Advanced users, customization

- Requires Python 3.11+
- See `LOCAL_SETUP.md` for detailed instructions
- Full source code access

---

## Setup Instructions

### 1. Configure Settings

Edit `config.ini`:

```ini
[discord]
channel_ids = YOUR_CHANNEL_ID_1,YOUR_CHANNEL_ID_2
allowed_author_ids = OPTIONAL_AUTHOR_ID_FILTER
allowed_guild_ids = OPTIONAL_GUILD_ID_FILTER

[webull]
paper_trade = true  # Set to false for live trading
```

### 2. Set Credentials via Replit Secrets (REQUIRED - ONLY SECURE METHOD)

**⚠️ SECURITY WARNING**: You MUST use Replit Secrets for all credentials. Never store credentials in config.ini.

Click the 🔒 **Secrets** icon in the left sidebar and add:

**Required Secrets:**
- `DISCORD_USER_TOKEN` - Your Discord user token
- `WEBULL_TRADE_PIN` - Your 6-digit trading PIN

**Choose ONE authentication method:**

**Method A: Username/Password (Will prompt for login)**
- `WEBULL_USERNAME` - Your Webull email
- `WEBULL_PASSWORD` - Your Webull password

**Method B: Saved Tokens (Faster, no login prompt)**
- `WEBULL_ACCESS_TOKEN` - Your Webull access token
- `WEBULL_REFRESH_TOKEN` - Your Webull refresh token
- `WEBULL_DID` - Your Webull device ID

**How to get your Discord user token:**
1. Open Discord in your browser
2. Press F12 to open Developer Tools
3. Go to Console tab
4. Paste: `(webpackChunkdiscord_app.push([[''],{},e=>{m=[];for(let c in e.c)m.push(e.c[c])}]),m).find(m=>m?.exports?.default?.getToken!==void 0).exports.default.getToken()`
5. Copy the token and add it to Replit Secrets as `DISCORD_USER_TOKEN`

**How to get Webull tokens (Method B):**
1. Open https://app.webull.com in your browser and log in
2. Press F12 → Console tab
3. Paste this code:
```javascript
console.log(JSON.stringify({
  accessToken: sessionStorage.accessToken || localStorage.accessToken || localStorage.ACCESS_TOKEN || '',
  refreshToken: sessionStorage.refreshToken || localStorage.refreshToken || localStorage.REFRESH_TOKEN || '',
  did: sessionStorage.did || localStorage.did || sessionStorage.deviceId || localStorage.deviceId || ''
}));
```
4. Copy the values and add them to Replit Secrets as `WEBULL_ACCESS_TOKEN`, `WEBULL_REFRESH_TOKEN`, and `WEBULL_DID`

## Running the Bot

The bot will start automatically when you run the Repl. Check the console for:
- ✓ Discord login confirmation
- ✓ Webull login confirmation
- ✓ List of monitored channels
- ✓ Paper trading mode status

## Testing

1. **Start with paper trading enabled** (`paper_trade = true`)
2. Send a test signal in a monitored channel
3. Check console logs to verify signal detection
4. Verify the paper trade is logged (no real order placed)

## Safety Features

- **Paper Trading Mode**: Test without risking real money
- **Author Filtering**: Only accept signals from specific users
- **Guild Filtering**: Only monitor specific servers
- **Channel Filtering**: Only specific channels are monitored
- **Comprehensive Logging**: All actions are logged for review

## Troubleshooting

### Bot not detecting signals
- Verify channel IDs are correct in config.ini
- Check author/guild filters aren't blocking messages
- Review console logs for parsing errors

### Webull login fails
- Verify credentials are correct
- Check if 2FA is enabled (may need manual token bootstrap)
- Ensure trade PIN is exactly 6 digits

### Orders not executing
- Check if paper_trade is enabled
- Verify Webull account has sufficient funds
- Review console logs for specific errors

## Security Best Practices

1. ✅ Use environment variables for all sensitive data
2. ✅ Keep config.ini in .gitignore
3. ✅ Never share your Discord token or Webull credentials
4. ✅ Start with paper trading enabled
5. ✅ Monitor logs regularly for suspicious activity

## Support

This is unofficial software. For issues:
1. Check console logs for error messages
2. Verify all credentials are correct
3. Test with paper trading first
4. Review signal format carefully

## License

Use at your own risk. No warranty provided.
